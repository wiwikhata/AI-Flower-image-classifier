from PIL import Image
import matplotlib.pyplot as plt
import * from {train.py}
# TODO: Write a function that loads a checkpoint and rebuilds the model
def load_checkpoint(filepath):
    checkpoint = torch.load(filepath)
    model = fc_model.Network(checkpoint["input_size"],
                             checkpoint["output_size"],
                             checkpoint["hidden_layers"])
    model.load_state_dict(checkpoint["state_dict"])
    
    return model


def process_image(image):
    
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    
    # TODO: Process a PIL image for use in a PyTorch model
    img = Image.open(image)
    #scaling
    width, height = img.size
    if width > height:
        ratio = width/height
        img.thumbnail((ratio* 256,256))
    if height > width:
        img.thumbnail((256,height/width * 256))
        new_width, new_height = img.size
        
    #cropping
        left = (new_width - 224)/2
        top = (new_height - 224)/2
        right = (new_width + 224)/2
        bottom = (new_height + 224)/2
        img.crop(left)
        img.crop(right)
        img.crop(top)
        img.crop(bottom)
        npar_img = np.array(img)
        npar_img = npar_img/225
        
     #normalizing
        mean = [0.485, 0.456, 0.406]
        std  = [0.229, 0.224, 0.225]
        npar_img = (npar_img - mean)/std
        npar_img.transpose((2,0,1))
    
    return np_img



def predict(image_path, model, topk=5):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    
    # TODO: Implement the code to predict the class from an image file
    process_img = torch.from_numpy(process_image(image_path))
    process_img.unsqueeze_(0)
    process_img = process_img.type(torch.FloatTensor)
    
    with torch.no_grad():
        output = model.foward(ps_img)
        probability,top_classes = output.topk(topk, dim= 1)
    
    return probability, top_classes


# TODO: Display an image along with the top 5 classes
plt.figure(figsize=(10,5))
img_path = 'flowers/test/10/image_07104.jpg'
probability, top_classes = predict(img_path, model)
img = Image.open('flowers/test/10/image_07104.jpg')
img = process_image(img)
idx = top_classes[0]
names = [cat_to_name[str(name)] for name in top_classes]
y_pos = np.arange(len(names))
performance = np.array(probability)

ax = plt.barh(y_pos, performance, align = 'center', color='blue')
plt.yticks(y_pos, names)
plt.gca().invert_yaxis()
 