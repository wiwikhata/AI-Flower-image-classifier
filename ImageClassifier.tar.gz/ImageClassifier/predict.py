from {functions.py} import load_checkpoint
from {functions.py} import process_image
from {functions.py} import predict

 predict(image_path, model, topk=5):
    